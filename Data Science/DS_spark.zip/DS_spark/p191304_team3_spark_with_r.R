# R command to check which version of java is installed on our system
system("java -version")
# installing sparklyr from CRAN
install.packages("sparklyr")
# Checking the installed version of sparklyr
packageVersion("sparklyr")
#loading sparklyr
library(sparklyr)

# CONNECTION
# connecting to the local spark cluster
sc <- spark_connect(master = "local", version = "3.0")
# The "master" parameter identifies which is the “main” machine from the Spark cluster;
# this machine is called as the driver node.
# While working with real clusters using many machines, we’ll find that most machines will be worker machines and one will be the master.
# Since we have only a local cluster with just one machine, we will default to using "local" for now.

# After a connection is established, spark_connect() retrieves an active Spark connection, which most code usually names sc;
# we will then make use of sc to execute Spark commands.

# Command data() will list all the datasets in loaded packages. 
data()

# copying the 'mtcars' dataset into Apache Spark by using 'copy_to()'
cars <- copy_to(sc, mtcars)
# The first parameter, sc, gives the function a reference to the active Spark connection that was created earlier with spark_connect().
# The second parameter specifies a dataset to load into Spark.
# copy_to() returns a reference to the dataset in Spark.
# The data was copied into Spark, we can access it from R using cars reference
head(cars)
summary(cars)
cars

# WEB INTERFACE
# Most of the Spark commands are executed from the R console, 
# however, monitoring and analyzing execution is done through Spark’s web interface
# which is a web application provided by Spark.
spark_web(sc) 

# Analysis
# When using Spark from R to analyze data, you can use SQL (Structured Query Language) or dplyr (a grammar of data manipulation)
library(DBI)  # we can use SQL through the DBI package
# counting number of records available in our cars dataset
dbGetQuery(sc, "SELECT count(*) FROM mtcars")

# when using dplyr we write less code, and it’s often much easier to write than SQL
library(dplyr)
count(cars)

# collecting data from Spark to perform data processing in R, like data visualization
# selecting, sampling, and plotting the cars dataset in Spark
select(cars, hp, mpg) %>%
  sample_n(100) %>%
  collect() %>%
  plot()

summarise_all(cars, mean)
# the show_query() command makes possible to peer into the SQL statement that sparklyr and dplyr created and sent to Spark. 
summarise_all(cars, mean) %>%
  show_query()

# A log is just a text file to which Spark appends information relevant to the execution of tasks in the cluster.
spark_log(sc)
spark_log(sc, filter = "sparklyr")

# Disconnecting
spark_disconnect(sc)
spark_disconnect_all()
