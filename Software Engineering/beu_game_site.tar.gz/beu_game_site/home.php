<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Online Games</title>
<link href="style.css" rel="stylesheet" type="text/css" />
</head>
<body>
<div id="templatemo_wrapper">
	<div id="templatemo_header">
    
        <div id="site_title">
            <img src="images/beu.png" alt="logo" />
        </div> <!-- end of site_title -->
        
        <div id="templatemo_menu">
            <ul>
                <li><a href="home.php">Home</a></li>
                <li><a href="games.html">Games</a></li>
              <li><a href="contact.html">Contact</a></li>
                <li class="last"><a href="logout.php">Log Out</a></li>
            </ul>    	
	    </div> <!-- end of templatemo_menu -->
    
    </div> <!-- end of header -->
    
    <div id="templatemo_main">
    	
        <div id="templatemo_content">
			
            <div class="content_box">
            	<h1>Welcome to Beu's Game site</h1>
                <p class="welcome_text">Did you know that the first video game was made in 1947?
		 It was called the Cathode Ray Tube Amusement Device.
		There's a lot of different kinds of games, such as: simulation, puzzle, 1st person shooter, action, adventure, RPG, MMO, and many other kinds.</p>
		<p>You too loves playing games?</p>
		<p>Hurray!</p>
		
          </div>
           <center> 
           <a href="games.html"><button>Play & Enjoy</button></a>
            
            
        </div> <!-- end of content -->
    
    	<div class="cleaner"></div>
    </div> <!-- end of main -->
    
     <div id="templatemo_footer">

        Copyright © 2020 <a href="#">Beulah_Evanjalin</a> | 
        All rights reserved by <a href="https://cutn.ac.in/">Central University of Tamilnadu</a>    
    </div> <!-- end of templatemo_footer -->
    
</div> <!-- end of warpper -->

</body>
</html>
