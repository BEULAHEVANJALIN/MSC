<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8" />
   <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
   <title>Register</title>
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <style>
      body{
      background: url(login_register.jpg) no-repeat fixed center center;
      background-size:cover;
      }
      
      #wrapper{
	width: 60%;
	right: 0px;
	min-height: 560px;	
	margin: 0px auto;	
	width: 500px;
	position: relative;
        	
      } 
      #wrapper h1{
	font-size: 48px;
	color: #f3a35c;
	padding: 2px 0 10px 0;
	font-family: sans-serif,Arial;
	font-weight: bold;
	text-align: center;
	padding-bottom: 15px;
      }
      #wrapper a{
	color: rgb(95, 155, 198);
	text-decoration: underline;
      }
      #wrapper p{
	margin-bottom:15px;
      }
     
      #wrapper label{
	color: #f3a35c;
	position: relative;
      }
      #wrapper input:not([type="checkbox"]){
	width: 92%;
	margin-top: 4px;
	padding: 10px 5px 10px 32px;	
	border: 1px solid rgb(178, 178, 178);
	-webkit-appearance: textfield;
	-webkit-box-sizing: content-box;
	  -moz-box-sizing : content-box;
	       box-sizing : content-box;
	-webkit-border-radius: 3px;
	   -moz-border-radius: 3px;
	        border-radius: 3px;
	-webkit-box-shadow: 0px 1px 4px 0px rgba(168, 168, 168, 0.6) inset;
	   -moz-box-shadow: 0px 1px 4px 0px rgba(168, 168, 168, 0.6) inset;
	        box-shadow: 0px 1px 4px 0px rgba(168, 168, 168, 0.6) inset;
	-webkit-transition: all 0.2s linear;
	   -moz-transition: all 0.2s linear;
	     -o-transition: all 0.2s linear;
	        transition: all 0.2s linear;
      }
        
      #register{
	position: absolute;
	top: 0px;
	width: 88%;	
	padding: 18px 6% 60px 6%;
	margin: 0 0 35px 0;
	background: #3d3630c4;
	border: 1px solid #f25b00;
	-webkit-box-shadow: 0pt 2px 5px #f3a35c,	0px 0px 8px 5px #f3a35c inset;
	   -moz-box-shadow: 0pt 2px 5px #f3a35c,	0px 0px 8px 5px #f3a35c inset;
	        box-shadow: 0pt 2px 5px #f3a35c,	0px 0px 8px 5px #f3a35c inset;
	-webkit-box-shadow: 5px;
	-moz-border-radius: 5px;
		 border-radius: 5px;
	 z-index: 22;
}
      
   
   </style>
</head>
<body>
   <div id="wrapper">
<div id="register">
<form  action="signup.php" method="POST"> 
<h1> REGISTER </h1> 
<p> 
<label for="usernamesignup" class="uname">Your username</label>
<input id="usernamesignup" name="username" required="required" type="text" placeholder="Username" />
</p>
<p> 
<label for="emailsignup" class="youmail" > Your email</label>
<input id="emailsignup" name="emailsignup" required="required" type="email" placeholder="my_mail@mail.com"/> 
</p>
<p> 
<label for="passwordsignup" class="youpasswd">Your password </label>
<input id="passwordsignup" name="password" required="required" type="password" placeholder="  *****  "/>
</p>
<p> 
<label for="passwordsignup_confirm" class="youpasswd" >Please confirm your password </label>
<input id="passwordsignup_confirm" name="passwordsignup_confirm" required="required" type="password" placeholder="  *****  "/>
</p>
<p class="signin button"> 
<input type="submit" name="register" value="Sign up"/> 
</p>
<label>Already a member ?</label>
<a href="index.php"> Login </a>
</p>
</form>
</div>
   </div>
   </div>
</body>