<?php
 
include('config.php');
session_start();
 
if (isset($_POST['register'])) {
 
    $username = $_POST['username'];
    $email = $_POST['emailsignup'];
    $password = $_POST['password'];
    $repassword = $_POST['passwordsignup_confirm'];
    
 
    $query = $connection->prepare("SELECT * FROM users WHERE USER_EMAIL=:emailsignup");
    $query->bindParam("emailsignup", $email, PDO::PARAM_STR);
    $query->execute();
 
    if ($query->rowCount() > 0) {
        echo '<p class="error">The email address is already registered!</p>';
    }


 
    if ($query->rowCount() == 0 && $password == $repassword) {
        $query = $connection->prepare("INSERT INTO users(USERNAME,PASSWORD,USER_EMAIL) VALUES (:username,:password,:email)");
        $query->bindParam("username", $username, PDO::PARAM_STR);
        $query->bindParam("password", $password, PDO::PARAM_STR);
        $query->bindParam("email", $email, PDO::PARAM_STR);
        $result = $query->execute();
 
        if ($result) {
            echo '<p class="success">Your registration was successful!</p>';
        } else {
            echo '<p class="error">Something went wrong!</p>';
        }
    }

    if ($password !== $repassword) {
    	echo'<p class="error">Password and Confirm password should match!</p>';   
    }

}
 
?>