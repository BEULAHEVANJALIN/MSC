int ceasarEncrypt(char c,int key,int offset);
